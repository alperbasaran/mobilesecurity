Java.perform(function () {
    var RootCheck = Java.use("sg.vantagepoint.a.c");

    // Override method a() to return false
    RootCheck.a.implementation = function () {
        console.log("[Bypass] c.a() called – returning false");
        return false;
    };

    // Override method b() to return false
    RootCheck.b.implementation = function () {
        console.log("[Bypass] c.b() called – returning false");
        return false;
    };

    // Override method c() to return false
    RootCheck.c.implementation = function () {
        console.log("[Bypass] c.c() called – returning false");
        return false;
    };

    console.log("[+] Root detection bypass hooks installed.");
})
