Java.perform(function() {
    var ArtMethod = Java.use("java.lang.reflect.ArtMethod");
    ArtMethod.invoke.implementation = function(obj, args) {
        console.log("[+] Method invoked: " + this.getName());
        return this.invoke(obj, args);
    };
});
