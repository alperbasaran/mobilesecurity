// This hooks method invocation at the Java reflection level instead of ART internals

Java.perform(function() {
    console.log("[+] Starting ART runtime monitoring...");
    
    // Method 1: Hook Java reflection API that ART uses internally
    var Method = Java.use("java.lang.reflect.Method");
    Method.invoke.overload('java.lang.Object', '[Ljava.lang.Object;').implementation = function(obj, args) {
        var className = "unknown";
        var methodName = "unknown";
        
        try {
            className = this.getDeclaringClass().getName();
            methodName = this.getName();
            
            // Filter to show only InsecureShop methods (reduce noise)
            if (className.includes("insecureshop") || className.includes("InsecureShop")) {
                console.log("[+] Method invoked via reflection:");
                console.log("    Class: " + className);
                console.log("    Method: " + methodName);
            }
        } catch (e) {
            // Ignore errors in logging
        }
        
        return this.invoke(obj, args);
    };
    
    // Method 2: Hook specific InsecureShop classes for demonstration
    try {
        // Hook the main activity or common classes
        var Activity = Java.use("android.app.Activity");
        Activity.onCreate.implementation = function(savedInstanceState) {
            console.log("[+] Activity onCreate called: " + this.getClass().getName());
            return this.onCreate(savedInstanceState);
        };
        
        // Hook HTTP networking (common in insecure apps)
        var HttpURLConnection = Java.use("java.net.HttpURLConnection");
        HttpURLConnection.setRequestMethod.implementation = function(method) {
            console.log("[+] HTTP Request: " + method + " to " + this.getURL());
            return this.setRequestMethod(method);
        };
        
    } catch (e) {
        console.log("[-] Could not hook specific classes: " + e);
    }
    
    // Method 3: Hook at the native level (more advanced)
    // This hooks the actual ART method invocation at native level
    var artMethod = null;
    var symbols = Module.enumerateSymbolsSync("libart.so");
    
    for (var i = 0; i < symbols.length; i++) {
        var symbol = symbols[i];
        // Look for ART method invoke symbols
        if (symbol.name.indexOf("art") !== -1 && 
            symbol.name.indexOf("Method") !== -1 && 
            symbol.name.indexOf("Invoke") !== -1) {
            
            console.log("[+] Found ART symbol: " + symbol.name + " at " + symbol.address);
            
            try {
                Interceptor.attach(symbol.address, {
                    onEnter: function(args) {
                        // Only log every 100th call to avoid spam
                        if (Math.random() < 0.01) {
                            console.log("[+] Native ART method invocation detected");
                        }
                    }
                });
                break;
            } catch (e) {
                // Symbol might not be hookable
                continue;
            }
        }
    }
    
    console.log("[+] ART runtime monitoring setup complete");
});

