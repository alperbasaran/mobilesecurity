Java.perform(function(){
    var strstr_fun = Module.findExportByName(null,"strstr")
    Interceptor.attach(strstr_fun,{
        onEnter : function(args){
             this.frida = ptr(args[0]).readCString()
             if (this.frida.indexOf("frida")>=0){
                }
        },
        onLeave: function(retval){
            retval.replace(0)
        }
    })
    let RootDetection = Java.use("sg.vantagepoint.util.RootDetection");
    RootDetection.checkRoot1.implementation = function(){
        console.log("[+] Bypassing the first Root Detection check")
        return false
    }
    RootDetection.checkRoot2.implementation = function(){
        console.log("[+] Bypassing the second Root Detection check")
        return false
    }
    RootDetection.checkRoot3.implementation = function(){
        console.log("[+] Bypassing the third Root Detection check")
        return false
    } 
})